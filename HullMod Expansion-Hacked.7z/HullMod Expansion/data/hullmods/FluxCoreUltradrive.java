package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public class FluxCoreUltradrive extends BaseHullMod {
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getFluxDissipation().modifyMult(id , 1.5f);
		stats.getFluxCapacity().modifyMult(id, 1.5f);
		stats.getEmpDamageTakenMult().modifyPercent(id, 50f);
		stats.getDynamic().getStat(Stats.SHIELD_PIERCED_MULT).modifyMult(id, 2f);
		stats.getHardFluxDissipationFraction().modifyFlat(id, 0.2f);
	}
	
	    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 40 + "%";
        }
		if (index == 1) {
            return "" + 10 + "%";
        }
		if (index == 2) {
            return "" + 50 + "%";
        }
		if (index == 3) {
            return "" + 100 + "%";
        }
		if (index == 4) {
            return "" + 20 + "%";
        }
		
        return null;
    }
	
	public String getUnapplicableReason(ShipAPI ship) {
		if(ship.getVariant().hasHullMod("safetyoverrides"))
			return "Incompatible With Safety Overrides";
			
		if(ship.getVariant().hasHullMod("hmp_fusioncore"))
			return "Incompatible With Fusion Cells";
		
		if(ship.getVariant().hasHullMod("hmp_fluxcoreoverdrive"))
			return "Incompatible With Flux Core Overdrive";
		return null;
		}
			
	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (!ship.getVariant().getHullMods().contains("safetyoverrides")&&
		(!ship.getVariant().getHullMods().contains("hmp_fusioncore"))&&
		(!ship.getVariant().getHullMods().contains("hmp_fluxcoreoverdrive")));
		}
	
    public void advanceInCombat(ShipAPI ship, float amount){
		MutableShipStatsAPI stats = ship.getMutableStats();
		if (ship.getFluxTracker().isVenting() == true){
			stats.getArmorDamageTakenMult().modifyMult("FluxCoreUltradrive" , 1.2f);
			stats.getShieldDamageTakenMult().modifyMult("FluxCoreUltradrive" , 1.2f);
			stats.getHullDamageTakenMult().modifyMult("FluxCoreUltradrive" , 1.2f);
		}
		else{
			stats.getArmorDamageTakenMult().modifyMult("FluxCoreUltradrive" , 1f);
			stats.getShieldDamageTakenMult().modifyMult("FluxCoreUltradrive" , 1f);
			stats.getHullDamageTakenMult().modifyMult("FluxCoreUltradrive" , 1f);
		}
	}
}