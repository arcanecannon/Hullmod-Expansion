package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI.*;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class RedMatrix extends BaseHullMod {


	private static Color Matrix_Color = new Color(0.6f, 0.0f, 0f, 0.7f);
	private static Color Shield_Color = new Color(0.2f, 0.2f, 0.4f, 0.5f);




				@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		if (!ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
			stats.getFluxDissipation().modifyMult(id , 0.85f);
			stats.getFluxCapacity().modifyMult(id , 0.85f);
		}
	}
	
	
	
		public String getUnapplicableReason(ShipAPI ship) {
			if ((ship.getShield() == null) ||
				(ship.getVariant().hasHullMod("hmp_weaponsystemenergizer"))||
				(ship.getVariant().hasHullMod("swp_shieldbypass"))||
				(ship.getVariant().hasHullMod("hmp_crystalizedarmor"))||
				(ship.getVariant().hasHullMod("tahlan_forcedoverdrive")))
            return "Ship Has No Shield";
			
			if (ship.getVariant().hasHullMod("hmp_submattershield"))
			return "Incompatible with Submatter Shield";
		
			if (ship.getVariant().hasHullMod("hmp_deltashield"))
			return "Incompatible with Delta Shield";
		
		return null;
	}
		
		
		public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getDefenseType() == ShieldType.FRONT || ship.getHullSpec().getDefenseType() == ShieldType.OMNI) &&
		(!ship.getVariant().getHullMods().contains("swp_shieldbypass"))&&
		(!ship.getVariant().getHullMods().contains("hmp_weaponsystemenergizer"))&&
		(!ship.getVariant().getHullMods().contains("SRD_prototype_nullpoint_shield"))&&
		(!ship.getVariant().getHullMods().contains("hmp_crystalizedarmor"))&&
		(!ship.getVariant().getHullMods().contains("hmp_submattershield"))&&
		(!ship.getVariant().getHullMods().contains("hmp_deltashield"))&&
		(!ship.getVariant().getHullMods().contains("tahlan_forcedoverdrive"))&&
		(ship.getShield() != null);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) {
            return "" + 15 + "%";
        }
        if (index == 1) {
            return "" + 10 +" seconds";
        }
		if (index == 2) {
            return "Immune to all damage";
        }
		if (index == 3) {
            return "" + 30 + " seconds";
        }
        return null;
    }
	
	
	public void advanceInCombat(ShipAPI ship, float amount) {
			if (!ship.isAlive()) return;		
			MutableShipStatsAPI stats = ship.getMutableStats();
			
			
			float Timer = Global.getCombatEngine().getTotalElapsedTime(false);
			ship.getMutableStats().getDynamic().getStat("hmp_RM_T").modifyFlat("hmp_RM_T" , -1f);
			ship.getMutableStats().getDynamic().getStat("hmp_RM_S").modifyFlat("hmp_RM_S" , -1f);
			
			if (Timer > 30)
				if (ship.getMutableStats().getDynamic().getStat("hmp_RM_T").getModifiedValue() < Timer) {
					ship.getMutableStats().getDynamic().getStat("hmp_RM_S").modifyFlat("hmp_RM_S2" , ship.getMutableStats().getDynamic().getStat("hmp_RM_S").getModifiedValue() + amount);
			
					stats.getShieldDamageTakenMult().modifyMult("RedMatrix", 0f );
					
					
					ship.getShield().setInnerColor(Matrix_Color);
					
					
					Global.getSoundPlayer().playLoop("Emergency_System", ship, 1f, 1f, ship.getLocation(), ship.getVelocity());
					
					
					if (ship.getMutableStats().getDynamic().getStat("hmp_RM_S").getModifiedValue() > 10f){
						ship.getMutableStats().getDynamic().getStat("hmp_RM_T").modifyFlat("hmp_RM_T2" , Timer + 30f);
						ship.getMutableStats().getDynamic().getStat("hmp_RM_S").modifyFlat("hmp_RM_S2" , 0f);
					}
				}
				else {
					stats.getShieldDamageTakenMult().modifyMult("RedMatrix", 1f );
					ship.getShield().setInnerColor(Shield_Color);
				}
	}
}