package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

public class HyperVelocityUpgrade extends BaseHullMod {
	
	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
			MutableShipStatsAPI stats = ship.getMutableStats();
			
		if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
			stats.getProjectileSpeedMult().modifyPercent("HyperVelocityUpgrade" , 85f);
		}
		
		else if (ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
			
			stats.getBallisticRoFMult().modifyMult("HyperVelocityUpgrade" , 0.4f);
			stats.getEnergyRoFMult().modifyMult("HyperVelocityUpgrade" , 0.4f);
			stats.getProjectileSpeedMult().modifyPercent("HyperVelocityUpgrade" , 100f);
			stats.getBallisticWeaponDamageMult().modifyMult( "WeaponControlCore", 2f);
			stats.getEnergyWeaponDamageMult().modifyMult( "WeaponControlCore", 2f);
		}
		else{
			stats.getBallisticRoFMult().modifyMult("HyperVelocityUpgrade" , 0.85f);
			stats.getEnergyRoFMult().modifyMult("HyperVelocityUpgrade" , 0.85f);
			stats.getProjectileSpeedMult().modifyPercent("HyperVelocityUpgrade" , 100f);
		}
	}

	
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 100 + "%";
        }
        if (index == 1) {
            return "" + 15 + "%";
        }
        return null;
    }
}