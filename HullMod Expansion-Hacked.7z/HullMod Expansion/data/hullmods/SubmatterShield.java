package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

public class SubmatterShield extends BaseHullMod {
	
	public static Color CENTER_COLOR = new Color(0.37f, 0f, 0.60f, 0.60f);
    public static Color RING_COLOR = new Color(0.20f, 0f, 0.30f, 0.40f);
	
	
				@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		
		if (ship.getVariant().hasHullMod("hmp_betasubsystem")){
			stats.getShieldDamageTakenMult().modifyMult("SubmatterShield2", 0.85f);
		}
	}
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
			stats.getShieldDamageTakenMult().modifyMult("SubmatterShield", 2f);
			stats.getShieldUpkeepMult().modifyMult("SubmatterShield", 0f);
	}
	    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "hard flux dissipation";
		}
		if (index == 1) {
            return "x2";
		}
		if (index == 2) {
            return "doesn't consume flux while active";
		}
		if (index == 3) {
			return "hard flux dissipation is disabled while Ship systems are active";
		}
        return null;
    }
		
		
		public String getUnapplicableReason(ShipAPI ship) {
		if ((ship.getShield() == null) ||
		(ship.getVariant().hasHullMod("hmp_weaponsystemenergizer"))||
		(ship.getVariant().hasHullMod("hmp_crystalizedarmor"))||
		(ship.getVariant().hasHullMod("tahlan_forcedoverdrive")))
            return "Ship Has No Shield";
		if ((ship.getVariant().hasHullMod("frontemitter"))||
		(ship.getVariant().hasHullMod("frontshield"))||
		(ship.getVariant().hasHullMod("adaptiveshields"))||
		(ship.getVariant().hasHullMod("stabilizedshieldemitter"))||
		(ship.getVariant().hasHullMod("extendedshieldemitter"))||
		(ship.getVariant().hasHullMod("hardenedshieldemitter"))||
		(ship.getVariant().hasHullMod("brshields"))||
		(ship.getVariant().hasHullMod("hmp_deltashield"))||
		(ship.getVariant().hasHullMod("hmp_redmatrix"))||
		(ship.getVariant().hasHullMod("SRD_prototype_nullpoint_shield")))
            return "Incompatible With All Other Shield Mods";
		return null;
	}
		
		
		public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getDefenseType() == ShieldType.FRONT || ship.getHullSpec().getDefenseType() == ShieldType.OMNI) &&
		((!ship.getVariant().getHullMods().contains("frontemitter"))&&
		(!ship.getVariant().getHullMods().contains("frontshield"))&&
		(!ship.getVariant().getHullMods().contains("adaptiveshields"))&&
		(!ship.getVariant().getHullMods().contains("stabilizedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("extendedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hardenedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hmp_redmatrix"))&&
		(!ship.getVariant().getHullMods().contains("hmp_weaponsystemenergizer"))&&
		(!ship.getVariant().getHullMods().contains("SRD_prototype_nullpoint_shield"))&&
		(!ship.getVariant().getHullMods().contains("hmp_crystalizedarmor"))&&
		(!ship.getVariant().getHullMods().contains("hmp_traxymiumarmor"))&&
		(!ship.getVariant().getHullMods().contains("tahlan_forcedoverdrive"))&&
		(!ship.getVariant().getHullMods().contains("hmp_deltashield"))&&
		(!ship.getVariant().getHullMods().contains("brshields"))&&
		(ship.getShield() != null));
	}
	
	    public void advanceInCombat(ShipAPI ship, float amount) {
			if (!ship.isAlive()) return;
		    MutableShipStatsAPI stats = ship.getMutableStats();
			
			ship.getShield().setInnerColor(CENTER_COLOR);
			ship.getShield().setRingColor(RING_COLOR);
			
					if (ship.getSystem().isActive() == true){
						stats.getHardFluxDissipationFraction().modifyFlat("SubmatterShield", 0f);
						return;
					}
					if (ship.getShield().isOn() == true){
					stats.getHardFluxDissipationFraction().modifyFlat("SubmatterShield", 1f);
					Global.getSoundPlayer().playLoop("Shield", ship, 1f, 2f, ship.getLocation(), ship.getVelocity());
					}
					else
						stats.getHardFluxDissipationFraction().modifyFlat("SubmatterShield", 0f);
		}
}
		