package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;

public class HyperEngineUpgrade extends BaseHullMod {
	
	public static final float MANEUVER_BONUS = 30f;
	private Color Engines_color = new Color(40,70,200,255);
	
	
		@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
			stats.getMaxSpeed().modifyFlat(id, 15f);
			stats.getEngineDamageTakenMult().modifyMult(id, 1.5f);
		}
	}
	
	
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getZeroFluxMinimumFluxLevel().modifyFlat(id, 2f);
		stats.getZeroFluxSpeedBoost().modifyFlat(id , -20f);
		stats.getAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
		stats.getDeceleration().modifyPercent(id, MANEUVER_BONUS);
		stats.getTurnAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
		stats.getMaxTurnRate().modifyPercent(id, MANEUVER_BONUS);
	}
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + "zero-flux movement speed bonus at any flux level";
        }
		if (index == 1) {
            return "" + 80 + "%";
        }
        if (index == 2) {
            return "" + 30 + "%";
        }
        return null;
    }
		@Override
	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && 
		((ship.getVariant().getHullSize() == HullSize.CAPITAL_SHIP) &&
		(!ship.getVariant().getHullMods().contains("hmp_nanohull")) &&
		(!ship.getVariant().getHullMods().contains("hmp_ultimateengineupgrade")));
	}
		
		public String getUnapplicableReason(ShipAPI ship) {
			if (ship.getVariant().hasHullMod("hmp_nanohull")) {
				return "Incompatible with Nano Hull";
			}
			if (ship.getVariant().hasHullMod("hmp_ultimateengineupgrade")) {
				return "An Upgraded version already exists";
			}
			if (ship.getVariant().getHullSize() != HullSize.CAPITAL_SHIP){
				return "Can be Only Installed capital ships";
			}
		return null;
	}
	
	public void advanceInCombat(ShipAPI ship, float amount) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		ship.getEngineController().fadeToOtherColor(this, Engines_color, null, 1f, 0.4f);
		ship.getEngineController().extendFlame(this, 0.4f, 0.4f, 0.4f);
	}
}

			
			