package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;

public class HeavyExplosiveAmmunition extends BaseHullMod {
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
	stats.getProjectileSpeedMult().modifyPercent(id,-30f);
	stats.getBallisticWeaponDamageMult().modifyPercent(id,15f);
	}
	    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 15 + "%";
        }
        if (index == 1) {
            return "" + 30 + "%";
        }
        return null;
    }
}