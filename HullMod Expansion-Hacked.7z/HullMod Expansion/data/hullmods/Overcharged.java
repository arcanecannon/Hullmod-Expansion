package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.GameState;

public class Overcharged extends BaseHullMod {
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 25 + "%";
		}
		if (index == 1) {
            return "4 seconds";
		}
		if (index == 2) {
            return "15 second";
		}
        return null;
    }
	
	
	    public void advanceInCombat(ShipAPI ship, float amount){
			
			MutableShipStatsAPI stats = ship.getMutableStats();
			ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
			float Timer = Global.getCombatEngine().getTotalElapsedTime(false);
			ship.getMutableStats().getDynamic().getStat("hmp_OC_T").modifyFlat("hmp_OC_T1" , -1f);
			ship.getMutableStats().getDynamic().getStat("hmp_OC_S").modifyFlat("hmp_OC_S1" , -1f);
			if (Timer > ship.getMutableStats().getDynamic().getStat("hmp_OC_T").getModifiedValue()){
				if (ship.getSystem().isActive() == true || ship.getMutableStats().getDynamic().getStat("hmp_OC_S").getModifiedValue() > 0f){
					ship.getMutableStats().getDynamic().getStat("hmp_OC_S").modifyFlat("hmp_OC_S2" , ship.getMutableStats().getDynamic().getStat("hmp_OC_S").getModifiedValue() + amount);
					
					if (ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
						stats.getHullDamageTakenMult().modifyMult("OverCharged" , 0.5f);
						stats.getArmorDamageTakenMult().modifyMult("OverCharged" , 0.5f);
						stats.getShieldDamageTakenMult().modifyMult("OverCharged" , 0.5f);
					}
					stats.getBallisticRoFMult().modifyMult( "OverCharged", 1.25f);
					stats.getEnergyRoFMult().modifyMult( "OverCharged", 1.25f);
					if (ship.getMutableStats().getDynamic().getStat("hmp_OC_S").getModifiedValue() > 4f){
						ship.getMutableStats().getDynamic().getStat("hmp_OC_T").modifyFlat("hmp_OC_T2" , Timer + 15f);
						ship.getMutableStats().getDynamic().getStat("hmp_OC_S").modifyFlat("hmp_OC_S2" , 0f);
					}
						
					if (ship == playerShip)
						Global.getCombatEngine().maintainStatusForPlayerShip("Overcharged", "graphics/icons/hullsys/active_flare_launcher.png",
						"Overcharged","" + 25 + "% Increased rate of fire",true);
						
			}
			else{	
				stats.getBallisticRoFMult().modifyMult( "OverCharged", 1f);
				stats.getEnergyRoFMult().modifyMult( "OverCharged", 1f);
				stats.getHullDamageTakenMult().modifyMult("OverCharged" , 1f);
				stats.getArmorDamageTakenMult().modifyMult("OverCharged" , 1f);
				stats.getShieldDamageTakenMult().modifyMult("OverCharged" , 1f);
			}
		}
		else{	
			stats.getBallisticRoFMult().modifyMult( "OverCharged", 1f);
			stats.getEnergyRoFMult().modifyMult( "OverCharged", 1f);
			stats.getHullDamageTakenMult().modifyMult("OverCharged" , 1f);
			stats.getArmorDamageTakenMult().modifyMult("OverCharged" , 1f);
			stats.getShieldDamageTakenMult().modifyMult("OverCharged" , 1f);
			
		}
	}
}