package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class SigmaSubsystem extends BaseHullMod {
	
		public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
			stats.getTimeMult().modifyMult(id, 1.07f);
		}	

		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "7%";
        }
		if (index == 1) {
            return "Increases and reductions to weapon damage applies to missiles instead at twice of their value.";
        }
		if (index == 2) {
            return "Active buff grants 50% reduced damage taken from all sources.";
        }
		if (index == 3) {
            return "Replaces weapon damage bonus with 1% Reduced weapon flux usage for every 2% flux you have";
        }
		if (index == 4) {
            return "Now grants 30% more weapon range instead.";
        }
		if (index == 5) {
            return "Increases damage by an equal amount but rate of fire penalty becomes -60%.";
        }
		if (index == 6) {
            return "Missiles have unlimited range but reducess their rate of fire by 70%.";
        }
		if (index == 7) {
            return "Shield takes +50% more damage while hard flux levels are below 70%, and -50% damage otherwise.";
        }
		if (index == 8) {
            return "Reduction against energy and high explosive damage is increased to 40%, Hull and armor takes 300% kinetic damage.";
        }
		if (index == 9) {
            return "No longer applies a flux penalty.";
        }
        return null;
    }
	
		public String getUnapplicableReason(ShipAPI ship) {
				if(ship.getVariant().hasHullMod("hmp_alphasubsystem") || ship.getVariant().hasHullMod("hmp_betasubsystem"))
					return "Another unique upgrade is already installed.";
				return null;
			}
			public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && (!ship.getVariant().getHullMods().contains("hmp_alphasubsystem")&&
				(!ship.getVariant().getHullMods().contains("hmp_betasubsystem")));
			}
}

			
			