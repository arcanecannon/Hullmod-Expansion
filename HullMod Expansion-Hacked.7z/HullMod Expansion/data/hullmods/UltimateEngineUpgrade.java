package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;


public class UltimateEngineUpgrade extends BaseHullMod {
	
	public static final float MANEUVER_BONUS = 30f;
	private Color Engines = new Color(230,230,255,255);
	
	
	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
			stats.getMaxSpeed().modifyFlat(id, 15f);
			stats.getEngineDamageTakenMult().modifyMult(id, 1.5f);
		}
	}
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getZeroFluxMinimumFluxLevel().modifyFlat(id, 2f);
		stats.getAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
		stats.getDeceleration().modifyPercent(id, MANEUVER_BONUS);
		stats.getTurnAcceleration().modifyPercent(id, MANEUVER_BONUS * 2f);
		stats.getMaxTurnRate().modifyPercent(id, MANEUVER_BONUS);
		stats.getEngineHealthBonus().modifyPercent(id, 50f);
	}
	
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 100 + "%";
		}
		if (index == 1) {
            return "0-flux speed boost at any flux level";
        }
        if (index == 2) {
            return "" + 50 + "%";
        }
        return null;
    }
		@Override
	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && 
		((ship.getVariant().getHullSize() == HullSize.CAPITAL_SHIP) &&
		(!ship.getVariant().getHullMods().contains("hmp_nanohull")) &&
		(!ship.getVariant().getHullMods().contains("hmp_plasmainjector")) &&
		(!ship.getVariant().getHullMods().contains("hmp_hyperengineupgrade")));
	}
		
		public String getUnapplicableReason(ShipAPI ship) {
			if (ship.getVariant().hasHullMod("hmp_nanohull")) {
				return "Incompatible with Nano Hull";
			}
			if (ship.getVariant().hasHullMod("hmp_hyperengineupgrade")) {
				return "Incompatible with Hyper Engine Upgrade";
			}
			if (ship.getVariant().hasHullMod("hmp_plasmainjector")) {
				return "Incompatible with Plasma Injector";
			}
			if (ship.getVariant().getHullSize() != HullSize.CAPITAL_SHIP)
				return "Can be Only Installed on capital ships";
		return null;
	}
		    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		ship.getEngineController().fadeToOtherColor(this, Engines, null, 1f, 0.4f);
		ship.getEngineController().extendFlame(this, 0.6f, 0.6f, 0.6f);
	}
}

			
			