package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;

public class FusionCore extends BaseHullMod {
public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
	}
	 public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "60 Second";
        }
		if (index == 1) {
            return "" + 85 +"%";
        }
		if (index == 2) {
            return "" + 300 +"%";
        }
		if (index == 3) {
            return "5 Seconds";
        }
		if (index == 4) {
            return "3 Charges";
        }
		if (index == 5) {
            return "Safety Override";
        }
		if (index == 6) {
            return "Flux Core Overdrive";
        }
		
        return null;
    }
	
	
	
	
	public String getUnapplicableReason(ShipAPI ship) {
			if(ship.getVariant().hasHullMod("safetyoverrides"))
				return "Incompatible With Safety Overrides";
			
			if(ship.getVariant().hasHullMod("hmp_fluxcoreoverdrive"))
				return "Incompatible With Flux Core Overdrive";
			
			if(ship.getVariant().hasHullMod("hmp_fluxcoreultradrive"))
				return "Incompatible With Flux Core Ultradrive";
			return null;
			}
			
			
			
			
	public boolean isApplicableToShip(ShipAPI ship) {
			return ship != null && (!ship.getVariant().getHullMods().contains("safetyoverrides")&&
			(!ship.getVariant().getHullMods().contains("hmp_fluxcoreoverdrive"))&&
			(!ship.getVariant().getHullMods().contains("hmp_fluxcoreultradrive")));
			}
			
			
				@Override
	public void advanceInCombat(ShipAPI ship, float amount) {	
		if (!ship.isAlive()) return;
        MutableShipStatsAPI stats = ship.getMutableStats();
		float Timer = Global.getCombatEngine().getTotalElapsedTime(false);
		ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
		float Flux = ship.getFluxTracker().getFluxLevel();
		ship.getMutableStats().getDynamic().getStat("hmp_FC_S").modifyFlat("hmp_FC_S1" , -1f);
		ship.getMutableStats().getDynamic().getStat("hmp_FC_T").modifyFlat("hmp_FC_T1" , -1f);
		ship.getMutableStats().getDynamic().getStat("hmp_FC_C").modifyFlat("hmp_FC_C1" , -1f);
		if (ship.getVariant().hasHullMod("hmp_betasubsystem")){
			if (ship.getMutableStats().getDynamic().getStat("hmp_FC_C").getModifiedValue() < 5f){					//checks how many times it activated during current battle.
				if (ship.getMutableStats().getDynamic().getStat("hmp_FC_T").getModifiedValue() <= (Timer)){					//checkes if it was activated in the past 60 seconds.
					if ((Flux >= 0.85f) || (ship.getMutableStats().getDynamic().getStat("hmp_FC_S").getModifiedValue() > 0f)){		//checks if the flux level meets the activation threshold.
						Global.getSoundPlayer().playLoop("Fusion", ship, 1f, 1f, ship.getLocation(), ship.getVelocity());
						stats.getHardFluxDissipationFraction().modifyFlat("FusionCore", 1f);
						stats.getFluxDissipation().modifyMult("FusionCore" , 3f);
						ship.getMutableStats().getDynamic().getStat("hmp_FC_S").modifyFlat("hmp_FC_S2" , ship.getMutableStats().getDynamic().getStat("hmp_FC_S").getModifiedValue() + amount);
						if (ship == playerShip)
						Global.getCombatEngine().maintainStatusForPlayerShip("FCore", "graphics/icons/hullsys/high_energy_focus.png","Fusion Cells Active:", "3x Flux Boost" ,false);
						if (ship.getMutableStats().getDynamic().getStat("hmp_FC_S").getModifiedValue() >= 5f){
							ship.getMutableStats().getDynamic().getStat("hmp_FC_S").modifyFlat("hmp_FC_S2" , 0f);
							ship.getMutableStats().getDynamic().getStat("hmp_FC_T").modifyFlat("hmp_FC_T2" , Timer + 60f);
							ship.getMutableStats().getDynamic().getStat("hmp_FC_C").modifyFlat("hmp_FC_C2" , ship.getMutableStats().getDynamic().getStat("hmp_FC_C").getModifiedValue() + 1f);
						}
					}
				}
				else{
					stats.getHardFluxDissipationFraction().modifyFlat("FusionCore", 0f);
					stats.getFluxDissipation().modifyMult("FusionCore" , 1f);
			}
		}
		else{
			stats.getHardFluxDissipationFraction().modifyFlat("FusionCore", 0f);
			stats.getFluxDissipation().modifyMult("FusionCore" , 1f);
			}
		}
		else{
			if (ship.getMutableStats().getDynamic().getStat("hmp_FC_C").getModifiedValue() < 3f){					//checks how many times it activated during current battle.
				if (ship.getMutableStats().getDynamic().getStat("hmp_FC_T").getModifiedValue() <= (Timer)){					//checkes if it was activated in the past 60 seconds.
					if ((Flux >= 0.85f) || (ship.getMutableStats().getDynamic().getStat("hmp_FC_S").getModifiedValue() > 0f)){		//checks if the flux level meets the activation threshold.
						Global.getSoundPlayer().playLoop("Fusion", ship, 1f, 1f, ship.getLocation(), ship.getVelocity());
						stats.getHardFluxDissipationFraction().modifyFlat("FusionCore", 1f);
						stats.getFluxDissipation().modifyMult("FusionCore" , 3f);
						ship.getMutableStats().getDynamic().getStat("hmp_FC_S").modifyFlat("hmp_FC_S2" , ship.getMutableStats().getDynamic().getStat("hmp_FC_S").getModifiedValue() + amount);
						if (ship == playerShip)
						Global.getCombatEngine().maintainStatusForPlayerShip("FCore", "graphics/icons/hullsys/high_energy_focus.png","Fusion Cells Active:", "3x Flux Boost" ,false);
						if (ship.getMutableStats().getDynamic().getStat("hmp_FC_S").getModifiedValue() >= 5f){
							ship.getMutableStats().getDynamic().getStat("hmp_FC_S").modifyFlat("hmp_FC_S2" , 0f);
							ship.getMutableStats().getDynamic().getStat("hmp_FC_T").modifyFlat("hmp_FC_T2" , Timer + 60f);
							ship.getMutableStats().getDynamic().getStat("hmp_FC_C").modifyFlat("hmp_FC_C2" , ship.getMutableStats().getDynamic().getStat("hmp_FC_C").getModifiedValue() + 1f);
						}
					}
				}
				else{
					stats.getHardFluxDissipationFraction().modifyFlat("FusionCore", 0f);
					stats.getFluxDissipation().modifyMult("FusionCore" , 1f);
			}
		}
		else{
			stats.getHardFluxDissipationFraction().modifyFlat("FusionCore", 0f);
			stats.getFluxDissipation().modifyMult("FusionCore" , 1f);
			}
		}
	}
}








