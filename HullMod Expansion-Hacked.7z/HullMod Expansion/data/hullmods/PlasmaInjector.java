package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class PlasmaInjector extends BaseHullMod {
	
	
		private Color Plasma_Engines = new Color(20,255,20,255);


			@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		
		if (ship.getVariant().hasHullMod("hmp_betasubsystem"))
			stats.getEngineDamageTakenMult().modifyMult(id, 0f);
	}

		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 30 + " Second";
        }
		if (index == 1) {
            return "+" + 100;
        }
        if (index == 2) {
            return "" + 300 + "%";
        }
		if (index == 3) {
            return "" + 6 + " Seconds";
        }
		if (index == 4) {
            return "Hyper Engine Upgrade";
        }
        return null;
    }
	
	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && 
		(!ship.getVariant().getHullMods().contains("safetyoverrides")) &&
		(!ship.getVariant().getHullMods().contains("hmp_ultimateengineupgrade"));
	}
	
	public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getVariant().hasHullMod("safetyoverrides"))
			return "Incompatible With Safety Overrides";
			
		if (ship.getVariant().hasHullMod("hmp_ultimateengineupgrade"))
			return "Incompatible with Ultimate Engine Upgrade";
		return null;
		}
	
	
	public void advanceInCombat(ShipAPI ship, float amount){
		
			MutableShipStatsAPI stats = ship.getMutableStats();
			ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
			float Timer = Global.getCombatEngine().getTotalElapsedTime(false);
			
			
			if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
				ship.getMutableStats().getDynamic().getStat("hmp_PI_T").modifyFlat("hmp_PI_T1" , -1f);
				ship.getMutableStats().getDynamic().getStat("hmp_PI_S").modifyFlat("hmp_PI_S1" , -1f);
			
			
				if (Timer > 12)
					if (ship.getMutableStats().getDynamic().getStat("hmp_PI_T").getModifiedValue() < Timer) {
						ship.getMutableStats().getDynamic().getStat("hmp_PI_S").modifyFlat("hmp_PI_S2" , ship.getMutableStats().getDynamic().getStat("hmp_PI_S").getModifiedValue() + amount);
			
						stats.getMaxSpeed().modifyFlat("PlasmaInjector" , 100f);
						stats.getMaxTurnRate().modifyMult("PlasmaInjector" , 3f);
					
					
						stats.getAcceleration().modifyMult("PlasmaInjector" , 2f);
						stats.getTurnAcceleration().modifyMult("PlasmaInjector" , 2f);
					
						ship.getEngineController().fadeToOtherColor(this, Plasma_Engines , null, 1f, 0.4f);
						ship.getEngineController().extendFlame(this, 1f, 1f, 1f);
					
						Global.getSoundPlayer().playLoop("system_plasma_jets_loop", ship, 1f, 0.75f, ship.getLocation(), ship.getVelocity());
					
					
						if (ship.getMutableStats().getDynamic().getStat("hmp_PI_S").getModifiedValue() > 12f){
							ship.getMutableStats().getDynamic().getStat("hmp_PI_T").modifyFlat("hmp_PI_T2" , Timer + 45f);
							ship.getMutableStats().getDynamic().getStat("hmp_PI_S").modifyFlat("hmp_PI_S2" , 0f);
						}
			
				}
				else {
					stats.getMaxSpeed().modifyFlat("PlasmaInjector" , 0f);
					stats.getMaxTurnRate().modifyMult("PlasmaInjector" , 1f);
			
					stats.getAcceleration().modifyMult("PlasmaInjector" , 1f);
					stats.getTurnAcceleration().modifyMult("PlasmaInjector" , 1f);
				}
			}
			else{
				ship.getMutableStats().getDynamic().getStat("hmp_PI_T").modifyFlat("hmp_PI_T1" , -1f);
				ship.getMutableStats().getDynamic().getStat("hmp_PI_S").modifyFlat("hmp_PI_S1" , -1f);
			
			
				if (Timer > 12)
					if (ship.getMutableStats().getDynamic().getStat("hmp_PI_T").getModifiedValue() < Timer) {
						ship.getMutableStats().getDynamic().getStat("hmp_PI_S").modifyFlat("hmp_PI_S2" , ship.getMutableStats().getDynamic().getStat("hmp_PI_S").getModifiedValue() + amount);
			
						stats.getMaxSpeed().modifyFlat("PlasmaInjector" , 100f);
						stats.getMaxTurnRate().modifyMult("PlasmaInjector" , 3f);
					
					
						stats.getAcceleration().modifyMult("PlasmaInjector" , 2f);
						stats.getTurnAcceleration().modifyMult("PlasmaInjector" , 2f);
					
						ship.getEngineController().fadeToOtherColor(this, Plasma_Engines , null, 1f, 0.4f);
						ship.getEngineController().extendFlame(this, 1f, 1f, 1f);
					
						Global.getSoundPlayer().playLoop("system_plasma_jets_loop", ship, 1f, 0.75f, ship.getLocation(), ship.getVelocity());
					
					
						if (ship.getMutableStats().getDynamic().getStat("hmp_PI_S").getModifiedValue() > 6f){
							ship.getMutableStats().getDynamic().getStat("hmp_PI_T").modifyFlat("hmp_PI_T2" , Timer + 30f);
							ship.getMutableStats().getDynamic().getStat("hmp_PI_S").modifyFlat("hmp_PI_S2" , 0f);
						}
			
			}
			else {
				stats.getMaxSpeed().modifyFlat("PlasmaInjector" , 0f);
				stats.getMaxTurnRate().modifyMult("PlasmaInjector" , 1f);
			
				stats.getAcceleration().modifyMult("PlasmaInjector" , 1f);
				stats.getTurnAcceleration().modifyMult("PlasmaInjector" , 1f);
			}
		}
	}
}

			
			