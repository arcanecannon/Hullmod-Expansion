package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI.*;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class QuantumShiftEngine extends BaseHullMod {


	private static final Color TRAIL_COLOR = new Color(0.1f, 0.1f, 0.3f, 0.02f);
	private static final Color PHASE_TRAIL_COLOR = new Color(0.12f, 0.12f, 0.4f, 0.07f);


	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		
		stats.getPhaseCloakUpkeepCostBonus().modifyMult("QuantumShiftEngine", -1.25f);
		stats.getPhaseCloakActivationCostBonus().modifyMult("QuantumShiftEngine", 0f);
		stats.getFluxDissipation().modifyMult("QuantumShiftEngine", 0f);
		stats.getZeroFluxSpeedBoost().modifyMult("QuantumShiftEngine" , 0.5f);
	}


	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) {
            return "Replaces the ship phase engine with a Quantum one";
		}
		if (index == 1) {
            return "" + 125 + "%";
		}
		if (index == 2) {
            return "" + 40 + "%";
		}
		if (index == 3) {
            return "-" + 30 + "%";
		}
		if (index == 4) {
            return "" + 100 + "%";
		}
		if (index == 5) {
            return "" + 50 + "%";
		}
		return null;
	}
	
	
	
	public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getHullSpec().getDefenseType() != ShieldType.PHASE)
			return "This upgrade is exclusive to Phase Ships";
		
		if (ship.getVariant().hasHullMod("safetyoverrides"))
			return "Incompatible With Safety Overrides";
		return null;
	}
	
	
	
	public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && ship.getHullSpec().getDefenseType() == ShieldType.PHASE && (!ship.getVariant().getHullMods().contains("safetyoverrides"));
	}
	
	
	
	public void advanceInCombat(ShipAPI ship, float amount) {
			if (!ship.isAlive()) return;
			
					
			MutableShipStatsAPI stats = ship.getMutableStats();
			ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
			float Flux = ship.getFluxLevel();
			if (Flux > 0.02f && ship.isPhased()){
				stats.getTimeMult().modifyMult("QuantumShiftEngine", 1.4f);
				if (ship == playerShip)
					Global.getCombatEngine().maintainStatusForPlayerShip("QuantumShiftEngine", "graphics/icons/hullsys/active_flare_launcher.png",
					"Quantum Shift","Time Acceleration at x1.4",true);
					Vector2f initialOffset = MathUtils.getRandomPointInCircle(null, 2f);
					Vector2f specificOffset = MathUtils.getRandomPointInCircle(initialOffset, 10f);
							ship.addAfterimage(
							PHASE_TRAIL_COLOR,
							specificOffset.x,
							specificOffset.y,
							ship.getVelocity().getX() * (-1f), 	// Horizontal speed modifier.
							ship.getVelocity().getY() * (-1f), 	// Vertical speed modifier.
							0.5f, 	//jitter (Distortion).
							0.5f, 	//Enter duration.
							2f,   	//Stay duration.
							0.5f, 	//Exit duration.
							true, 	//Additive blend.
							false, 	//Combine with sprite color.
							false  	//Above ship.
							);
							Global.getSoundPlayer().playLoop("Shift", ship, 1f, 1.4f, ship.getLocation(), ship.getVelocity());
			}
			else if (ship.isPhased()){
			stats.getTimeMult().modifyMult("QuantumShiftEngine", 0.7f);
			if (ship == playerShip)
					Global.getCombatEngine().maintainStatusForPlayerShip("QuantumShiftEngine", "graphics/icons/hullsys/active_flare_launcher.png",
					"Quantum Shift","Time Acceleration at x0.7",true);
			}
			else {
			stats.getTimeMult().modifyMult("QuantumShiftEngine", 1f);
			Vector2f initialOffset2 = MathUtils.getRandomPointInCircle(null, 0f);
			Vector2f specificOffset2 = MathUtils.getRandomPointInCircle(initialOffset2, 5f);
							ship.addAfterimage(
							TRAIL_COLOR,
							specificOffset2.x,
							specificOffset2.y,
							ship.getVelocity().getX() * (-1f), 	// Horizontal speed modifier.
							ship.getVelocity().getY() * (-1f), 	// Vertical speed modifier.
							0.5f, 	//jitter (Distortion).
							1f, 	//Enter duration.
							7f,   	//Stay duration.
							1f, 	//Exit duration.
							true, 	//Additive blend.
							false, 	//Combine with sprite color.
							false  	//Above ship.
							);
		}
	}
}