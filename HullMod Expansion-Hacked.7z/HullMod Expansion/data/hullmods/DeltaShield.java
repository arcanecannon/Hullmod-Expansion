package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI.*;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class DeltaShield extends BaseHullMod {


	public static Color SHIELD_COLOR = new Color(0.7f, 0.7f, 0f, 0.8f);


	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getShieldDamageTakenMult().modifyMult("DeltaShield", 0.85f);
		stats.getShieldUpkeepMult().modifyMult("DeltaShield", 0.01f);
		stats.getFluxCapacity().modifyPercent("DeltaShield", 30f);
		stats.getShieldTurnRateMult().modifyPercent("DeltaShield", 70f);
		stats.getShieldUnfoldRateMult().modifyPercent("DeltaShield", 70f);
	}


	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) {
            return "Hard Flux";
		}
		if (index == 1) {
            return "" + 15 + "%";
		}
		if (index == 2) {
            return "" + 1 + "%";
		}
		if (index == 3) {
            return "" + 2 + "%";
		}
		if (index == 4) {
            return "" + 1 + "%";
		}
		if (index == 5) {
            return "" + 3 + "%";
		}
		if (index == 6) {
            return "" + 1 + "%";
		}
		if (index == 7) {
            return "" + 30 + "%";
		}
		if (index == 8) {
            return "" + 70 + "%";
		}
		return null;
	}
	
	
	
		public String getUnapplicableReason(ShipAPI ship) {
		if ((ship.getShield() == null) ||
		(ship.getVariant().hasHullMod("hmp_weaponsystemenergizer"))||
		(ship.getVariant().hasHullMod("hmp_crystalizedarmor"))||
		(ship.getVariant().hasHullMod("tahlan_forcedoverdrive")))
            return "Ship Has No Shield";
		if ((ship.getVariant().hasHullMod("frontemitter"))||
		(ship.getVariant().hasHullMod("frontshield"))||
		(ship.getVariant().hasHullMod("advancedshieldemitter"))||
		(ship.getVariant().hasHullMod("adaptiveshields"))||
		(ship.getVariant().hasHullMod("stabilizedshieldemitter"))||
		(ship.getVariant().hasHullMod("extendedshieldemitter"))||
		(ship.getVariant().hasHullMod("hardenedshieldemitter"))||
		(ship.getVariant().hasHullMod("SRD_prototype_nullpoint_shield"))||
		(ship.getVariant().hasHullMod("hmp_submattershield"))||
		(ship.getVariant().hasHullMod("hmp_redmatrix"))||
		(ship.getVariant().hasHullMod("brshields")))
            return "Incompatible With All Other Shield Mods";
		return null;
	}
		
		
		public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getDefenseType() == ShieldType.FRONT || ship.getHullSpec().getDefenseType() == ShieldType.OMNI) &&
		((!ship.getVariant().getHullMods().contains("frontemitter"))&&
		(!ship.getVariant().getHullMods().contains("frontshield"))&&
		(!ship.getVariant().getHullMods().contains("advancedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("adaptiveshields"))&&
		(!ship.getVariant().getHullMods().contains("stabilizedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("extendedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hardenedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hmp_weaponsystemenergizer"))&&
		(!ship.getVariant().getHullMods().contains("SRD_prototype_nullpoint_shield"))&&
		(!ship.getVariant().getHullMods().contains("hmp_crystalizedarmor"))&&
		(!ship.getVariant().getHullMods().contains("hmp_redmatrix"))&&
		(!ship.getVariant().getHullMods().contains("tahlan_forcedoverdrive"))&&
		(!ship.getVariant().getHullMods().contains("hmp_submattershield"))&&
		(!ship.getVariant().getHullMods().contains("brshields"))&&
		(ship.getShield() != null));
	}
	
	
	
	public void advanceInCombat(ShipAPI ship, float amount) {
			if (!ship.isAlive()) return;		
			MutableShipStatsAPI stats = ship.getMutableStats();
			ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
			float HardFlux = ship.getFluxTracker().getHardFlux();
			float MaxFlux = ship.getFluxTracker().getMaxFlux();
			float HardFluxPercent = HardFlux / MaxFlux;
			float Flux = ship.getFluxTracker().getFluxLevel();
			
			stats.getShieldDamageTakenMult().modifyMult("DeltaShield", 0.85f - ( 0.5f * HardFluxPercent));
			stats.getShieldUpkeepMult().modifyMult("DeltaShield", 0.01f + (3f * HardFluxPercent));
			
			if (ship.getVariant().hasHullMod("hmp_sigmasubsystem"))
				if (Flux < 0.7f)
					stats.getShieldDamageTakenMult().modifyMult("DeltaShield2", 1.5f);
				else
					stats.getShieldDamageTakenMult().modifyMult("DeltaShield2", 0.5f);
				
			
			ship.getShield().setInnerColor(SHIELD_COLOR);
			ship.getShield().setRingColor(SHIELD_COLOR);
			
			if (ship.getShield().isOn() == true)
			Global.getSoundPlayer().playLoop("Shift", ship, 1f, 0.75f, ship.getLocation(), ship.getVelocity());
	}
}