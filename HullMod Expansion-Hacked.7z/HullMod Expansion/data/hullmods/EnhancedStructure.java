package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class EnhancedStructure extends BaseHullMod {
	
	
	
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getHullBonus().modifyMult(id , 1.1f);
		stats.getArmorBonus().modifyMult(id , 1.1f);
		stats.getDynamic().getStat(Stats.CORONA_EFFECT_MULT).modifyMult(id, 0.4f);
		stats.getPeakCRDuration().modifyPercent(id, 20f);
	}
	
				@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		
		if (ship.getVariant().hasHullMod("hmp_betasubsystem")){
			stats.getKineticDamageTakenMult().modifyMult(id, 0.65f);
			stats.getFragmentationDamageTakenMult().modifyMult(id, 0.65f);
			stats.getEnergyDamageTakenMult().modifyMult(id , 0.9f);
			stats.getHighExplosiveDamageTakenMult().modifyMult(id , 0.9f);
		}
		else if (ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
			stats.getKineticDamageTakenMult().modifyMult(id, 3f);
			stats.getEnergyDamageTakenMult().modifyMult(id , 0.6f);
			stats.getHighExplosiveDamageTakenMult().modifyMult(id , 0.6f);
		}
		else{
			stats.getEnergyDamageTakenMult().modifyMult(id , 0.9f);
			stats.getHighExplosiveDamageTakenMult().modifyMult(id , 0.9f);	
		}
	}
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 10 + "%";
        }
        if (index == 1) {
            return "" + 10 + "%";
        }
		if (index == 2) {
            return "" + 60 + "%";
        }
		if (index == 3) {
            return "" + 20 + "%";
        }
		
        return null;
    }
}