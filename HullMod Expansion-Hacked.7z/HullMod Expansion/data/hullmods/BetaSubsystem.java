package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class BetaSubsystem extends BaseHullMod {
	
		public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
			stats.getHullDamageTakenMult().modifyMult(id , 0.93f);
			stats.getArmorDamageTakenMult().modifyMult(id , 0.93f);
			stats.getShieldDamageTakenMult().modifyMult(id , 0.93f);
		}

		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "7%";
        }
		if (index == 1) {
            return "The hullmod may activate a second time at 10% hull for 3 seconds.";
        }
		if (index == 2) {
            return "Increases charge count by 2.";
        }
		if (index == 3) {
            return "Reduces time required to repair weapons and enegines by 50%.";
        }
		if (index == 4) {
            return "Reduces overall shield damage taken by 15%.";
        }
		if (index == 5) {
            return "Increases all missiles durability by 40%.";
        }
		if (index == 6) {
            return "Remove damage penalty.";
        }
		if (index == 7) {
            return "Engines can't be disabled.";
        }
		if (index == 8) {
            return "Reduces kinetic and fragmentation damage taken by hull and armor by 35%.";
        }
		if (index == 9) {
            return "Increases armor repair rate by 50%.";
        }
        return null;
    }
	
		public String getUnapplicableReason(ShipAPI ship) {
				if(ship.getVariant().hasHullMod("hmp_alphasubsystem") || ship.getVariant().hasHullMod("hmp_sigmasubsystem"))
					return "Another unique upgrade is already installed.";
				return null;
			}
			public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && (!ship.getVariant().getHullMods().contains("hmp_alphasubsystem")&&
				(!ship.getVariant().getHullMods().contains("hmp_sigmasubsystem")));
			}
}

			
			