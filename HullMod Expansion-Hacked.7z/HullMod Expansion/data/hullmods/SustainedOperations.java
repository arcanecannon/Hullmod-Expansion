package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI.*;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class SustainedOperations extends BaseHullMod {

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getMaxBurnLevel().modifyFlat(id , 1f);
		stats.getFuelUseMod().modifyPercent(id , -25f);
		stats.getSensorStrength().modifyPercent(id , 50f);
		stats.getMaxCombatReadiness().modifyFlat(id , -0.1f);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 1;
        }
        if (index == 1) {
            return "" + 20 + "%";
        }
		if (index == 2) {
            return "" + 50 + "%";
        }
		if (index == 3) {
            return "" + 20 + "%";
        }
		
        return null;
    }
}