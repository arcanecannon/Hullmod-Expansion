package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;

public class WeaponControlCore extends BaseHullMod {
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
	
		stats.getBallisticWeaponRangeBonus().modifyMult("WeaponControlCore", 1.15f);
		stats.getEnergyWeaponRangeBonus().modifyMult("WeaponControlCore", 1.15f);
		
		stats.getPeakCRDuration().modifyPercent("WeaponControlCore", -30f);

		stats.getBallisticWeaponFluxCostMod().modifyPercent("WeaponControlCore", -15f);
		stats.getEnergyWeaponFluxCostMod().modifyPercent("WeaponControlCore", -15f);
		
	}
	
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 25 + "%";
        }
        if (index == 1) {
            return "" + 15 + "%";
        }
		if (index == 2) {
            return "" + 15 + "%";
        }
		if (index == 3) {
            return "as your flux levels increases";
        }
		if (index == 4) {
            return "" + 1 + "%";
		}
		if (index == 5) {
            return "" + 1 + "%";
		}
		if (index == 6) {
            return "" + 4 + "%";
		}
		if (index == 7) {
            return "" + 30 + "%";
		}
        return null;
    }
			public String getUnapplicableReason(ShipAPI ship) {
				if(ship.getVariant().hasHullMod("hmp_combatanalysis"))
					return "Incompatible With Combat Analysis Unit";
				return null;
			}
			public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && (!ship.getVariant().getHullMods().contains("hmp_combatanalysis"));
			}
	
	    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        if (!ship.isAlive()) return;
        float Flux = ship.getFluxTracker().getFluxLevel();
		ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
        MutableShipStatsAPI stats = ship.getMutableStats();

		if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
			stats.getBallisticWeaponFluxCostMod().modifyPercent("WeaponControlCore", -20f);
			stats.getEnergyWeaponFluxCostMod().modifyPercent("WeaponControlCore", -20f);
			stats.getBallisticWeaponRangeBonus().modifyMult("WeaponControlCore", 1.25f);
			stats.getEnergyWeaponRangeBonus().modifyMult("WeaponControlCore", 1.25f);
			stats.getBallisticRoFMult().modifyMult( "WeaponControlCore", 1.3f - (0.25f * Flux));
			stats.getEnergyRoFMult().modifyMult( "WeaponControlCore", 1.3f - (0.25f * Flux));
			stats.getBallisticWeaponDamageMult().modifyMult( "WeaponControlCore", 1f + (0.25f * Flux));
			stats.getEnergyWeaponDamageMult().modifyMult( "WeaponControlCore", 1f + (0.25f * Flux));
			if (ship == playerShip){
				Global.getCombatEngine().maintainStatusForPlayerShip("WCS RoF", "graphics/icons/hullsys/high_energy_focus.png",
				"Weapon Control Supercomputer: ","+" + Math.round((0.3f - (0.25f * Flux)) * 100f) + "% Rate Of Fire",false);
				Global.getCombatEngine().maintainStatusForPlayerShip("WCS DpS", "graphics/icons/hullsys/high_energy_focus.png",
				"Weapon Control Supercomputer: ","+" + Math.round((0f + (0.25f * Flux)) * 100f) + "% Damage",false);
				}
		}
		else if (ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
			
			stats.getBallisticRoFMult().modifyMult( "WeaponControlCore", 1.25f - (0.25f * Flux));
			stats.getEnergyRoFMult().modifyMult( "WeaponControlCore", 1.25f - (0.25f * Flux));
			stats.getBallisticWeaponFluxCostMod().modifyPercent("WeaponControlCore", -15f - (50f * Flux));
			stats.getEnergyWeaponFluxCostMod().modifyPercent("WeaponControlCore", -15f - (50f * Flux));
			
			if (ship == playerShip){
				Global.getCombatEngine().maintainStatusForPlayerShip("WCS RoF", "graphics/icons/hullsys/high_energy_focus.png",
				"Weapon Control Supercomputer: ","+" + Math.round((0.25f - (0.25f * Flux)) * 100f) + "% Rate Of Fire",false);
				Global.getCombatEngine().maintainStatusForPlayerShip("WCS DpS", "graphics/icons/hullsys/high_energy_focus.png",
				"Weapon Control Supercomputer: ","+" + Math.round((0.15f + (0.5f * Flux)) * 100f) + "% Reduced weapon flux usage",false);
				}
		}
		else {
			stats.getBallisticRoFMult().modifyMult( "WeaponControlCore", 1.25f - (0.25f * Flux));
			stats.getEnergyRoFMult().modifyMult( "WeaponControlCore", 1.25f - (0.25f * Flux));
			stats.getBallisticWeaponDamageMult().modifyMult( "WeaponControlCore", 1f + (0.25f * Flux));
			stats.getEnergyWeaponDamageMult().modifyMult( "WeaponControlCore", 1f + (0.25f * Flux));
			if (ship == playerShip){
				Global.getCombatEngine().maintainStatusForPlayerShip("WCS RoF", "graphics/icons/hullsys/high_energy_focus.png",
				"Weapon Control Supercomputer: ","+" + Math.round((0.25f - (0.25f * Flux)) * 100f) + "% Rate Of Fire",false);
				Global.getCombatEngine().maintainStatusForPlayerShip("WCS DpS", "graphics/icons/hullsys/high_energy_focus.png",
				"Weapon Control Supercomputer: ","+" + Math.round((0f + (0.25f * Flux)) * 100f) + "% Damage",false);
			}
		}
    }
}