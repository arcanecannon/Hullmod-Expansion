package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

public class ReflectedRage extends BaseHullMod {
public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getShieldDamageTakenMult().modifyMult(id , 1.20f);
	}
		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "Require shields";
		}
		if (index == 1) {
            return "" + 20 + "%";
		}
		if (index == 2) {
            return "diverted";
		}
		if (index == 3) {
			return "" + 1 + "%";
		}
		if (index == 4) {
			return "" + 5 + "% Hardflux";
		}
		if (index == 5) {
			return "dropping shields";
		}
        return null;
    }

		public String getUnapplicableReason(ShipAPI ship) {
		if (ship == null || ship.getShield() == null ||
		(ship.getVariant().hasHullMod("swp_shieldbypass"))||
		(ship.getVariant().hasHullMod("hmp_weaponsystemenergizer"))||
		(ship.getVariant().hasHullMod("hmp_crystalizedarmor"))||
		(ship.getVariant().hasHullMod("hmp_traxymiumarmor")))
            return "Ship Has No Shield";
		return null;
	}
		
		
		public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getDefenseType() == ShieldType.FRONT || ship.getHullSpec().getDefenseType() == ShieldType.OMNI) &&
		((!ship.getVariant().getHullMods().contains("hmp_weaponsystemenergizer"))&&
		(!ship.getVariant().getHullMods().contains("swp_shieldbypass"))&&
		(!ship.getVariant().getHullMods().contains("hmp_crystalizedarmor"))&&
		(ship.getShield() != null) &&
		(!ship.getVariant().getHullMods().contains("hmp_traxymiumarmor")));
	}
	
		public void advanceInCombat(ShipAPI ship, float amount) {
		if (!ship.isAlive()) return;
	    MutableShipStatsAPI stats = ship.getMutableStats();
		ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
		float HardFlux = ship.getFluxTracker().getHardFlux();
		float MaxFlux = ship.getFluxTracker().getMaxFlux();
		if (ship.getShield().isOn() == false){
			stats.getBallisticWeaponDamageMult().modifyMult( "ReflectedRage", 1f + ( 1f * ((HardFlux / MaxFlux) / 5f)));
			stats.getEnergyWeaponDamageMult().modifyMult( "ReflectedRage", 1f + ( 1f * ((HardFlux / MaxFlux) / 5f)));
			if (ship == playerShip)
			Global.getCombatEngine().maintainStatusForPlayerShip("ReflectedRage", "graphics/icons/hullsys/phase_cloak.png",
			"Reflected Rage:","" + Math.round (100f * ((HardFlux / MaxFlux) / 5f)) + "% Increased Damage",true);
			}
		else{
			stats.getBallisticWeaponDamageMult().modifyMult( "ReflectedRage", 1f);
			stats.getEnergyWeaponDamageMult().modifyMult( "ReflectedRage", 1f);
		}
	}
}