package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class AlphaSubsystem extends BaseHullMod {
	
		public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
			stats.getBallisticWeaponDamageMult().modifyPercent( id, 7f);
			stats.getEnergyWeaponDamageMult().modifyPercent( id, 7f);
			
			
		}	

		    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "7%";
        }
		if (index == 1) {
            return "Weapon range bonus is increased by another 10% and rate of fire by 5%, All weapons flux usage is adjusted to -20%.";
        }
		if (index == 2) {
            return "Damage cap is increased to 40%, permanently increases hit strength bonus against armor (for damage reduction calculation only) by 35%.";
        }
		if (index == 3) {
            return "Increases weapon damage by another 5% and reduces all weapons flux usage by 10%.";
        }
		if (index == 4) {
            return "Doubled activation duration, activation threshold is now 60%.";
        }
		if (index == 5) {
            return "Removes rate of fire penalty, projectile speed bonus is adjusted to 80% instead.";
        }
		if (index == 6) {
            return "Removes missile damage penalty.";
        }
		if (index == 7) {
            return "Increases missile damage by 30%";
        }
		if (index == 8) {
            return "Double activation duration but increases recharge time by 50%.";
        }
		if (index == 9) {
            return "Further overdrives the ship engines adding +15 flat speed in all directions, engines takes 50% increased damage from all sources.";
        }
        return null;
    }
		public String getUnapplicableReason(ShipAPI ship) {
				if(ship.getVariant().hasHullMod("hmp_betasubsystem") || ship.getVariant().hasHullMod("hmp_sigmasubsystem"))
					return "Another unique upgrade is already installed.";
				return null;
			}
			public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && (!ship.getVariant().getHullMods().contains("hmp_betasubsystem")&&
				(!ship.getVariant().getHullMods().contains("hmp_sigmasubsystem")));
			}
}

			
			