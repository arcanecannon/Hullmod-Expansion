package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;

public class FocusingLense extends BaseHullMod {
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		
		stats.getBeamWeaponDamageMult().modifyPercent(id, 25f);
		stats.getBeamWeaponRangeBonus().modifyPercent(id, -35f);
	}
	    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 25 + "%";
        }
        if (index == 1) {
            return "-" + 35 + "%";
        }

        return null;
    }
}