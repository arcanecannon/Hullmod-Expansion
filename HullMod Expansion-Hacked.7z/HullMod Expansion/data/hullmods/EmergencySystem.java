package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.fleet.FleetMemberAPI;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;


public class EmergencySystem extends BaseHullMod {	

	private static final Color E_SYSTEM_COLOR = new Color(0.3f, 0.5f, 0.6f, 0.18f);

    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 20 + "%";
        }       
		if (index == 1) {
            return "Invulnerable for 5 seconds";
        }
		if (index == 2) {
            return "Removing Overload";
        }
		if (index == 3) {
            return "Instantly repairs all weapons and engines";
        }
		if (index == 4) {
            return "" + 3 + "%";
        }
		if (index == 5) {
            return "zero-flux speed boost to take effect regardless of flux levels";
        }
		if (index == 6) {
            return "Nano hull";
        }
        return null;
    }
	
    public String getUnapplicableReason(ShipAPI ship) {
			if (ship.getVariant().hasHullMod("hmp_nanohull"))
				return "Incompatible with Nano Hull";
		return null;
	}
	public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && (!ship.getVariant().getHullMods().contains("hmp_nanohull"));
	}

	    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        if (!ship.isAlive()) return;
		MutableShipStatsAPI stats = ship.getMutableStats();
		
		ship.getMutableStats().getDynamic().getStat("hmp_ES_S").modifyFlat("hmp_ES_S1" , -1f);
		ship.getMutableStats().getDynamic().getStat("hmp_ES_V").modifyFlat("hmp_ES_V1" , -1f);
			
		ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
		float CurrentHull = ship.getHitpoints();
		float MaxHull = ship.getMaxHitpoints();
		
		if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
			if (ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() < 10f){
				if ((CurrentHull < MaxHull * 0.6f) || ( ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() > 0f)){
				
					Vector2f initialOffset = MathUtils.getRandomPointInCircle(null, 40f);
					Vector2f specificOffset = MathUtils.getRandomPointInCircle(initialOffset, 30f);
							ship.addAfterimage(
							E_SYSTEM_COLOR,
							specificOffset.x,
							specificOffset.y,
							0f, 	// Horizontal speed modifier.
							0f, 	// Vertical speed modifier.
							0.4f, 	//jitter (Distortion).
							0.1f, 	//Enter duration.
							0.2f,   	//Stay duration.
							0.1f, 	//Exit duration.
							true, 	//Additive blend.
							false, 	//Combine with sprite color.
							false  	//Above ship.
							);
							Global.getSoundPlayer().playLoop("Emergency_System", ship, 1f, 1.5f, ship.getLocation(), ship.getVelocity());
				
					ship.getMutableStats().getDynamic().getStat("hmp_ES_S").modifyFlat("hmp_ES_S2" , ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() + amount);
					stats.getZeroFluxMinimumFluxLevel().modifyFlat("EmergencySystem", 2f);
					stats.getAcceleration().modifyPercent("EmergencySystem", 50f);
					stats.getDeceleration().modifyPercent("EmergencySystem", 25f);
					stats.getTurnAcceleration().modifyPercent("EmergencySystem", 50f);
					stats.getMaxTurnRate().modifyPercent("EmergencySystem", 25f);
					stats.getArmorDamageTakenMult().modifyMult("EmergencySystem" , 0f);
					stats.getShieldDamageTakenMult().modifyMult("EmergencySystem" , 0f);
					stats.getHullDamageTakenMult().modifyMult("EmergencySystem" , 0f);
					stats.getMaxCombatHullRepairFraction().modifyFlat("EmergencySystem" , 1f);
					stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("EmergencySystem" , 3f);
					stats.getHardFluxDissipationFraction().modifyFlat("EmergencySystem", 1f);
					stats.getFluxDissipation().modifyMult("EmergencySystem" , 2f);
					stats.getCombatEngineRepairTimeMult().modifyMult("EmergencySystem", 0.1f);
					stats.getCombatWeaponRepairTimeMult().modifyMult("EmergencySystem", 0.1f);
					stats.getEmpDamageTakenMult().modifyMult("EmergencySystem", 0f);
					if ((ship.getFluxTracker().isOverloaded()) && ( ship.getMutableStats().getDynamic().getStat("hmp_ES_V").getModifiedValue() == 0f)){
						ship.getFluxTracker().stopOverload();
						ship.getMutableStats().getDynamic().getStat("hmp_ES_V").modifyFlat("hmp_ES_V2" , 1f);
					}
					if (ship == playerShip)
						Global.getCombatEngine().maintainStatusForPlayerShip("ESystem", "graphics/icons/hullsys/temporal_shell.png","Emergency System ACTIVE:", "Damage immunity" ,false);
				}
			}
			else {
					stats.getEmpDamageTakenMult().modifyMult("EmergencySystem", 1f);
					stats.getCombatEngineRepairTimeMult().modifyMult("EmergencySystem", 1f);
					stats.getCombatWeaponRepairTimeMult().modifyMult("EmergencySystem", 1f);
					stats.getZeroFluxMinimumFluxLevel().unmodifyFlat("EmergencySystem");
					stats.getAcceleration().modifyPercent("EmergencySystem", 0f);
					stats.getDeceleration().modifyPercent("EmergencySystem", 0f);
					stats.getTurnAcceleration().modifyPercent("EmergencySystem", 0f);
					stats.getMaxTurnRate().modifyPercent("EmergencySystem", 0f);
					stats.getArmorDamageTakenMult().modifyMult("EmergencySystem" , 1f);
					stats.getShieldDamageTakenMult().modifyMult("EmergencySystem" , 1f);
					stats.getHullDamageTakenMult().modifyMult("EmergencySystem" , 1f);
					stats.getHardFluxDissipationFraction().modifyFlat("EmergencySystem", 0f);
					stats.getFluxDissipation().modifyMult("EmergencySystem" , 1f);
					stats.getMaxCombatHullRepairFraction().modifyFlat("EmergencySystem" , 0f);
					stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("EmergencySystem" , 0f);
			}
		}
		
		else{
		if (ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() < 5f){
			if ((CurrentHull < MaxHull * 0.2f) || ( ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() > 0f)){
				
				
				Vector2f initialOffset = MathUtils.getRandomPointInCircle(null, 40f);
				Vector2f specificOffset = MathUtils.getRandomPointInCircle(initialOffset, 30f);
							ship.addAfterimage(
							E_SYSTEM_COLOR,
							specificOffset.x,
							specificOffset.y,
							0f, 	// Horizontal speed modifier.
							0f, 	// Vertical speed modifier.
							0.4f, 	//jitter (Distortion).
							0.1f, 	//Enter duration.
							0.2f,   	//Stay duration.
							0.1f, 	//Exit duration.
							true, 	//Additive blend.
							false, 	//Combine with sprite color.
							false  	//Above ship.
							);
							Global.getSoundPlayer().playLoop("Emergency_System", ship, 1f, 1.5f, ship.getLocation(), ship.getVelocity());
				
				ship.getMutableStats().getDynamic().getStat("hmp_ES_S").modifyFlat("hmp_ES_S2" , ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() + amount);
				stats.getZeroFluxMinimumFluxLevel().modifyFlat("EmergencySystem", 2f);
				stats.getAcceleration().modifyPercent("EmergencySystem", 50f);
				stats.getDeceleration().modifyPercent("EmergencySystem", 25f);
				stats.getTurnAcceleration().modifyPercent("EmergencySystem", 50f);
				stats.getMaxTurnRate().modifyPercent("EmergencySystem", 25f);
				stats.getArmorDamageTakenMult().modifyMult("EmergencySystem" , 0f);
				stats.getShieldDamageTakenMult().modifyMult("EmergencySystem" , 0f);
				stats.getHullDamageTakenMult().modifyMult("EmergencySystem" , 0f);
				stats.getMaxCombatHullRepairFraction().modifyFlat("EmergencySystem" , 1f);
				stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("EmergencySystem" , 3f);
				stats.getHardFluxDissipationFraction().modifyFlat("EmergencySystem", 1f);
				stats.getFluxDissipation().modifyMult("EmergencySystem" , 2f);
				stats.getCombatEngineRepairTimeMult().modifyMult("EmergencySystem", 0.1f);
				stats.getCombatWeaponRepairTimeMult().modifyMult("EmergencySystem", 0.1f);
				stats.getEmpDamageTakenMult().modifyMult("EmergencySystem", 0f);
				if ((ship.getFluxTracker().isOverloaded()) && ( ship.getMutableStats().getDynamic().getStat("hmp_ES_V").getModifiedValue() == 0f)){
					ship.getFluxTracker().stopOverload();
					ship.getMutableStats().getDynamic().getStat("hmp_ES_V").modifyFlat("hmp_ES_V2" , 1f);
				}
				if (ship == playerShip)
					Global.getCombatEngine().maintainStatusForPlayerShip("ESystem", "graphics/icons/hullsys/temporal_shell.png","Emergency System ACTIVE:", "Damage immunity" ,false);
			}
		}
		else {
				stats.getEmpDamageTakenMult().modifyMult("EmergencySystem", 1f);
				stats.getCombatEngineRepairTimeMult().modifyMult("EmergencySystem", 1f);
				stats.getCombatWeaponRepairTimeMult().modifyMult("EmergencySystem", 1f);
				stats.getZeroFluxMinimumFluxLevel().unmodifyFlat("EmergencySystem");
				stats.getAcceleration().modifyPercent("EmergencySystem", 0f);
				stats.getDeceleration().modifyPercent("EmergencySystem", 0f);
				stats.getTurnAcceleration().modifyPercent("EmergencySystem", 0f);
				stats.getMaxTurnRate().modifyPercent("EmergencySystem", 0f);
				stats.getArmorDamageTakenMult().modifyMult("EmergencySystem" , 1f);
				stats.getShieldDamageTakenMult().modifyMult("EmergencySystem" , 1f);
				stats.getHullDamageTakenMult().modifyMult("EmergencySystem" , 1f);
				stats.getHardFluxDissipationFraction().modifyFlat("EmergencySystem", 0f);
				stats.getFluxDissipation().modifyMult("EmergencySystem" , 1f);
				stats.getMaxCombatHullRepairFraction().modifyFlat("EmergencySystem" , 0f);
				stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("EmergencySystem" , 0f);
		}
	}
		
		
		
		
		
		
		
		
		
		
		
		//Secondary effect if beta upgrade is installed*
		if (ship.getVariant().hasHullMod("hmp_betasubsystem") && (ship.getMutableStats().getDynamic().getStat("hmp_ES_S").getModifiedValue() >= 5f)){
			ship.getMutableStats().getDynamic().getStat("hmp_EC_S").modifyFlat("hmp_EC_S1" , -1f);
			ship.getMutableStats().getDynamic().getStat("hmp_EC_V").modifyFlat("hmp_EC_V1" , -1f);
			if (ship.getMutableStats().getDynamic().getStat("hmp_EC_S").getModifiedValue() < 3f){
			if ((CurrentHull < MaxHull * 0.1f) || ( ship.getMutableStats().getDynamic().getStat("hmp_EC_S").getModifiedValue() > 0f)){
				
				
				Vector2f initialOffset = MathUtils.getRandomPointInCircle(null, 40f);
				Vector2f specificOffset = MathUtils.getRandomPointInCircle(initialOffset, 30f);
							ship.addAfterimage(
							E_SYSTEM_COLOR,
							specificOffset.x,
							specificOffset.y,
							0f, 	// Horizontal speed modifier.
							0f, 	// Vertical speed modifier.
							0.4f, 	//jitter (Distortion).
							0.1f, 	//Enter duration.
							0.2f,   	//Stay duration.
							0.1f, 	//Exit duration.
							true, 	//Additive blend.
							false, 	//Combine with sprite color.
							false  	//Above ship.
							);
							Global.getSoundPlayer().playLoop("Emergency_System", ship, 1f, 1.5f, ship.getLocation(), ship.getVelocity());
				
				ship.getMutableStats().getDynamic().getStat("hmp_EC_S").modifyFlat("hmp_EC_S2" , ship.getMutableStats().getDynamic().getStat("hmp_EC_S").getModifiedValue() + amount);
				stats.getZeroFluxMinimumFluxLevel().modifyFlat("BEmergencySystem", 2f);
				stats.getAcceleration().modifyPercent("BEmergencySystem", 50f);
				stats.getDeceleration().modifyPercent("BEmergencySystem", 25f);
				stats.getTurnAcceleration().modifyPercent("BEmergencySystem", 50f);
				stats.getMaxTurnRate().modifyPercent("BEmergencySystem", 25f);
				stats.getArmorDamageTakenMult().modifyMult("BEmergencySystem" , 0f);
				stats.getShieldDamageTakenMult().modifyMult("BEmergencySystem" , 0f);
				stats.getHullDamageTakenMult().modifyMult("BEmergencySystem" , 0f);
				stats.getMaxCombatHullRepairFraction().modifyFlat("BEmergencySystem" , 1f);
				stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("BEmergencySystem" , 3f);
				stats.getHardFluxDissipationFraction().modifyFlat("BEmergencySystem", 1f);
				stats.getFluxDissipation().modifyMult("BEmergencySystem" , 2f);
				stats.getCombatEngineRepairTimeMult().modifyMult("BEmergencySystem", 0.1f);
				stats.getCombatWeaponRepairTimeMult().modifyMult("BEmergencySystem", 0.1f);
				stats.getEmpDamageTakenMult().modifyMult("BEmergencySystem", 0f);
				if ((ship.getFluxTracker().isOverloaded()) && ( ship.getMutableStats().getDynamic().getStat("hmp_EC_V").getModifiedValue() == 0f)){
					ship.getFluxTracker().stopOverload();
					ship.getMutableStats().getDynamic().getStat("hmp_EC_V").modifyFlat("hmp_EC_V2" , 1f);
				}
				if (ship == playerShip)
					Global.getCombatEngine().maintainStatusForPlayerShip("ESystem", "graphics/icons/hullsys/temporal_shell.png","Emergency System ACTIVE:", "Damage immunity" ,false);
			}
		}
		else {
				stats.getEmpDamageTakenMult().modifyMult("BEmergencySystem", 1f);
				stats.getCombatEngineRepairTimeMult().modifyMult("BEmergencySystem", 1f);
				stats.getCombatWeaponRepairTimeMult().modifyMult("BEmergencySystem", 1f);
				stats.getZeroFluxMinimumFluxLevel().unmodifyFlat("BEmergencySystem");
				stats.getAcceleration().modifyPercent("BEmergencySystem", 0f);
				stats.getDeceleration().modifyPercent("BEmergencySystem", 0f);
				stats.getTurnAcceleration().modifyPercent("BEmergencySystem", 0f);
				stats.getMaxTurnRate().modifyPercent("BEmergencySystem", 0f);
				stats.getArmorDamageTakenMult().modifyMult("BEmergencySystem" , 1f);
				stats.getShieldDamageTakenMult().modifyMult("BEmergencySystem" , 1f);
				stats.getHullDamageTakenMult().modifyMult("BEmergencySystem" , 1f);
				stats.getHardFluxDissipationFraction().modifyFlat("BEmergencySystem", 0f);
				stats.getFluxDissipation().modifyMult("BEmergencySystem" , 1f);
				stats.getMaxCombatHullRepairFraction().modifyFlat("BEmergencySystem" , 0f);
				stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("BEmergencySystem" , 0f);
		}
		}
	}
}