package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemSpecAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class DedicatedWeaponsCPU extends BaseHullMod {
	
		public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
			
		stats.getAutofireAimAccuracy().modifyFlat(id, 1f);
        stats.getMaxRecoilMult().modifyMult(id, 0.1f);
        stats.getRecoilPerShotMult().modifyMult(id, 0.1f);
		}	

		    public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) {
            return "Every weapon";
        }
        if (index == 1) {
            return "best possible auto-fire aim accuracy";
        }
		if (index == 2) {
            return "" + 90 + "%";
        }
        return null;
    }
}

			
			