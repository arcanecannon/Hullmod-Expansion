package data.hullmods;

import java.util.HashMap;
import java.util.Map;
import java.awt.*;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ArmorGridAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;


import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;


public class CrystalizedArmor extends BaseHullMod {
	
	
	
	
	private static Map mag = new HashMap();
		static {
			mag.put(HullSize.FRIGATE, 50f);
			mag.put(HullSize.DESTROYER, 100f);
			mag.put(HullSize.CRUISER, 200f);
			mag.put(HullSize.CAPITAL_SHIP, 300f);
	}
	
	
	
    private static final Color OUTLINE_COLOR = new Color(0f, 0.15f, 0.6f, 0.027f);
	private static final Color OVERLAY_COLOR = new Color(0f, 0.00f, 0.1f, 0.006f);
	
	
	
			@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
			ship.setShield(ShieldType.NONE, 0f, 0f, 90f);

	}
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getShieldUpkeepMult().modifyMult(id, 0f);
		stats.getShieldDamageTakenMult().modifyMult(id, 0f);
		stats.getArmorBonus().modifyFlat(id, (Float) mag.get(hullSize));
		stats.getArmorBonus().modifyMult(id, 1.3f);
		stats.getEmpDamageTakenMult().modifyMult(id, 0f);
		stats.getMaxSpeed().modifyPercent (id, -35f);
	}
	
		    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 50 + "/" + 100 + "/" + 200 + "/" + 300 ;
        }    
        if (index == 1) {
            return "" + 30 + "%";
        }  
        if (index == 2) {
            return "Immune";
        }  
        if (index == 3) {
            return "" + 35 + "%";
        }
		if (index == 4) {
            return "Ship has shields";
        }
		if (index == 5) {
            return "" + 20 + "%";
        }
		if (index == 6) {
            return "Ship has phase engine";
        }
		if (index == 7) {
            return "half";
        }
		if (index == 8) {
            return "" + 30 + "%";
        }
		if (index == 9) {
            return "" + 0.35 + "%";
        }
        return null;
    }
	
	
	    @Override
    public String getUnapplicableReason(ShipAPI ship) {
		if (ship.getVariant().hasHullMod("heavyarmor")) 
            return "Incompatible with Heavy Armor";
		
	    if (ship.getVariant().hasHullMod("frontemitter")) 
            return "Incompatible with Front Shield Emitter";
        
		if (ship.getVariant().hasHullMod("frontshield")) 
			return "Incompatible with Front Shield Generator";
        
		if (ship.getVariant().hasHullMod("advancedshieldemitter")) 
            return "Incompatible with Accelerated Shields";
        
        if (ship.getVariant().hasHullMod("adaptiveshields")) 
            return "Incompatible with Omni Shield Emitter";
        
        if (ship.getVariant().hasHullMod("stabilizedshieldemitter")) 
            return "Incompatible with Stabilized Shields";
        
		if (ship.getVariant().hasHullMod("extendedshieldemitter")) 
            return "Incompatible with Extended Shields";
        
        if (ship.getVariant().hasHullMod("hardenedshieldemitter")) 
            return "Incompatible with Hardened Shields";
        
		if (ship.getVariant().hasHullMod("hmp_submattershield")) 
			return "Incompatible with Submatter Shield";
		
		if (ship.getVariant().hasHullMod("hmp_reflectedrage")) 
			return "Incompatible with Reflected Rage";
		
		if (ship.getVariant().hasHullMod("vnsarmorrepair")) 
			return "Incompatible with Nano-Infused Armor";
		
		if (ship.getVariant().hasHullMod("ii_armor_package"))
			return "Incompatible with Imperium Armor Package";
		
		if (ship.getVariant().hasHullMod("PoweredArmour"))    
			return "Incompatible with Powered Armor";
		
		if (ship.getVariant().hasHullMod("hmp_deltashield"))
			return "Incompatible with Delta Shield";
		
		if (ship.getVariant().hasHullMod("hmp_redmatrix"))
			return "Incompatible with Red Matrix";
		
		if (ship.getVariant().hasHullMod("hmp_nanohull"))
			return "Incompatible with Nano Hull";
		return null;
		
		}
		
		
			public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null &&
		((!ship.getVariant().getHullMods().contains("frontemitter"))&&
		(!ship.getVariant().getHullMods().contains("frontshield"))&&
		(!ship.getVariant().getHullMods().contains("advancedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("adaptiveshields"))&&
		(!ship.getVariant().getHullMods().contains("stabilizedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("extendedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hardenedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hmp_submattershield"))&&
		(!ship.getVariant().getHullMods().contains("heavyarmor"))&&
		(!ship.getVariant().getHullMods().contains("hmp_reflectedrage"))&&
		(!ship.getVariant().getHullMods().contains("hmp_redmatrix"))&&
		(!ship.getVariant().getHullMods().contains("hmp_nanohull"))&&
		(!ship.getVariant().getHullMods().contains("vnsarmorrepair"))&&
		(!ship.getVariant().getHullMods().contains("ii_armor_package"))&&
		(!ship.getVariant().getHullMods().contains("hmp_deltashield"))&&
		(!ship.getVariant().getHullMods().contains("PoweredArmour")));
	}
	
    @Override
    public void advanceInCombat(ShipAPI ship, float amount){
		if (!ship.isAlive()) return;
		MutableShipStatsAPI stats = ship.getMutableStats();
		
		
			
			
		if (ship.getHullSpec().getDefenseType() == ShieldType.PHASE){
			stats.getZeroFluxSpeedBoost().modifyMult("CrystalizedArmor" , 0.5f);
			stats.getArmorDamageTakenMult().modifyPercent("CrystalizedArmor", -30f);
		}
		
		
		if (ship.getVariant().hasHullMod("hmp_betasubsystem")){
			final ArmorGridAPI armor = ship.getArmorGrid();
			final float[][] grid = armor.getGrid();
			HullSize hullSize = ship.getHullSize();		
			final float maxArmor = armor.getMaxArmorInCell();
			float toHeal =  maxArmor * (0.0053f) * amount;				
			for (int x = 0; x < grid.length; x++){
				for (int y = 0; y < grid[0].length; y++){
					armor.setArmorValue(x, y, Math.min(grid[x][y] + toHeal, maxArmor));
				}
			}
		}
		else{
			final ArmorGridAPI armor = ship.getArmorGrid();
			final float[][] grid = armor.getGrid();
			HullSize hullSize = ship.getHullSize();		
			final float maxArmor = armor.getMaxArmorInCell();
			float toHeal =  maxArmor * (0.0035f) * amount;				
			for (int x = 0; x < grid.length; x++){
				for (int y = 0; y < grid[0].length; y++){
					armor.setArmorValue(x, y, Math.min(grid[x][y] + toHeal, maxArmor));
				}
			}
		}
						Vector2f initialOffset = MathUtils.getRandomPointInCircle(null, 20f);
						Vector2f specificOffset = MathUtils.getRandomPointInCircle(initialOffset, 0f);
						ship.addAfterimage(
								OUTLINE_COLOR,
								specificOffset.x,
								specificOffset.y,
								0f,     // Horizontal speed modifier.
								0f,     // Vertical speed modifier.
								0f,  	// jitter (Distortion).
								0.3f,   //Enter duration.
								1f,     //Stay duration.
								0.3f,   //Exit duration.
								true,   //Additive blend.
								true,   //Combine with sprite color.
								false   //Above ship.
								);
						 initialOffset = MathUtils.getRandomPointInCircle(null, 0f);
						 specificOffset = MathUtils.getRandomPointInCircle(initialOffset, 0f);
								ship.addAfterimage(
								OVERLAY_COLOR,
								specificOffset.x,
								specificOffset.y,
								0f, // Horizontal speed modifier.
								0f, // Vertical speed modifier.
								0f, // jitter (Distortion).
								0.3f, //Enter duration.
								1f,   //Stay duration.
								0.3f, //Exit duration.
								true, //Additive blend.
								true, //Combine with sprite color.
								true  //Above ship.
								);
	}
}