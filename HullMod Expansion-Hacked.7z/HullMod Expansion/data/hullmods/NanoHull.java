package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;

public class NanoHull extends BaseHullMod {
	
			@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		MutableShipStatsAPI stats = ship.getMutableStats();
		
		if (ship.getVariant().hasHullMod("hmp_betasubsystem")){
			stats.getCombatEngineRepairTimeMult().modifyPercent(id, -50f);
			stats.getCombatWeaponRepairTimeMult().modifyPercent(id, -50f);
		}
	}


	 public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "Repair itself";
        }
        if (index == 1) {
            return "" + 0.6 + "%";
        }
		if (index == 2) {
            return "" + 20 + "%";
        }
		if (index == 3) {
            return "" + 3 + "%";
        }
		if (index == 4) {
            return "" + 1 + "%";
		}
		if (index == 5) {
            return "" + 1 + "%";
		}
		if (index == 6) {
            return "System is Disabled while Venting";
		}
        return null;
    }
	
	
	    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().hasHullMod("hmp_emergencysystem")) {
            return "Incompatible with Emergency System";
		}
		if (ship.getVariant().hasHullMod("hmp_hyperengineupgrade")) {
			return "Incompatible with Hyper Engine Upgrade";
		}
		if (ship.getVariant().hasHullMod("hmp_ultimateengineupgrade")) {
			return "Incompatible with Ultimate Engine Upgrade";
		}
		if (ship.getVariant().hasHullMod("hmp_crystalizedarmor")) {
			return "Incompatible with Crystallized Armor";
		}
		return null;
	}
		
			@Override
	public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && 
		(!ship.getVariant().getHullMods().contains("hmp_emergencysystem")) &&
		(!ship.getVariant().getHullMods().contains("hmp_hyperengineupgrade")) &&
		(!ship.getVariant().getHullMods().contains("hmp_crystalizedarmor")) &&
		(!ship.getVariant().getHullMods().contains("hmp_ultimateengineupgrade"));
	}

	
			@Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        MutableShipStatsAPI stats = ship.getMutableStats();
		if (!ship.isAlive()) return;
		float CurrentHull = ship.getHitpoints();
		float MaxHull = ship.getMaxHitpoints();
		float CurrentHullPercent = (CurrentHull / MaxHull) *100f;
		if (CurrentHull == MaxHull){
		//Disable Repairs
		stats.getMaxCombatHullRepairFraction().modifyFlat("NanoHull" , 0f);
		//Disable Repair at 100% Hull:
		stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("NanoHull" , 0f);
		//Flux Normalized at 100% Hull:
		stats.getFluxDissipation().modifyMult("NanoHull", 1f);
		}
		else{
			if (ship.getFluxTracker().isVenting() == true) {
				
			//Disable The Entire System While Venting.
			stats.getMaxCombatHullRepairFraction().modifyFlat("NanoHull" , 0f);
			stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("NanoHull" , 0f);
			stats.getFluxDissipation().modifyMult("NanoHull", 1f);
			
			}
			else{
			//Enable Repairs
			stats.getMaxCombatHullRepairFraction().modifyFlat("NanoHull" , 1f);
			//Repair 0.6%% Of Max Hull per 20% Of Missing Hull:
			stats.getHullCombatRepairRatePercentPerSecond().modifyFlat("NanoHull" , 0.6f * ((100f - CurrentHullPercent ) / 20f));
			//Flux Reduced by 1% per 1% missing Hull:
		    stats.getFluxDissipation().modifyMult("NanoHull", 1f - ((100f - CurrentHullPercent) * 0.01f));
			}
		}
		
	}
}