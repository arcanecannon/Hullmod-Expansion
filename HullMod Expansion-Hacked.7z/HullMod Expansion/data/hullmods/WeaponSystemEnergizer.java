package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;

public class WeaponSystemEnergizer extends BaseHullMod {
	    
		@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
		ship.setShield(ShieldType.NONE, 0f, 0f, 90f);
		
		MutableShipStatsAPI stats = ship.getMutableStats();
		stats.getShieldUpkeepMult().modifyMult("WeaponSystemEnergizer", 0f);
		stats.getShieldDamageTakenMult().modifyMult("WeaponSystemEnergizer", 0f);
			
		if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){
			
			stats.getBallisticRoFMult().modifyPercent( "WeaponSystemEnergizer", 15f);
			stats.getEnergyRoFMult().modifyPercent( "WeaponSystemEnergizer", 15f);
			stats.getBallisticWeaponDamageMult().modifyPercent( "WeaponSystemEnergizer", 15f);
			stats.getEnergyWeaponDamageMult().modifyPercent( "WeaponSystemEnergizer", 15f);
			
			stats.getBallisticWeaponFluxCostMod().modifyPercent("WeaponSystemEnergizer", -10f);
			stats.getEnergyWeaponFluxCostMod().modifyPercent("WeaponSystemEnergizer", -10f);
		}
		else if (ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
			
			stats.getBallisticWeaponRangeBonus().modifyMult("WeaponSystemEnergizer", 1.3f);
			stats.getEnergyWeaponRangeBonus().modifyMult("WeaponSystemEnergizer", 1.3f);
		}
		else {
			stats.getBallisticRoFMult().modifyPercent( "WeaponSystemEnergizer", 15f);
			stats.getEnergyRoFMult().modifyPercent( "WeaponSystemEnergizer", 15f);
			stats.getBallisticWeaponDamageMult().modifyPercent( "WeaponSystemEnergizer", 10f);
			stats.getEnergyWeaponDamageMult().modifyPercent( "WeaponSystemEnergizer", 10f);
		}
	}
	    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "" + 10 + "%";
        }       
		if (index == 1) {
            return "" + 15 + "%";
        }
		if (index == 2) {
            return "removing shields";
        }
        return null;
    }
	
	    @Override
    public String getUnapplicableReason(ShipAPI ship) {
		if ((ship.getVariant().hasHullMod("swp_shieldbypass")) ||
		(ship.getVariant().hasHullMod("tahlan_forcedoverdrive")) ||
		((ship.getHullSpec().getDefenseType() != ShieldType.FRONT && ship.getHullSpec().getDefenseType() != ShieldType.OMNI)))
            return "Ship Has No Shield";
		
	    if (ship.getVariant().hasHullMod("frontemitter")) 
            return "Incompatible with Front Shield Emitter";
        
		if (ship.getVariant().hasHullMod("frontshield")) 
			return "Incompatible with Front Shield Generator";
        
		if (ship.getVariant().hasHullMod("advancedshieldemitter")) 
            return "Incompatible with Accelerated Shields";
        
        if (ship.getVariant().hasHullMod("adaptiveshields")) 
            return "Incompatible with Omni Shield Emitter";
        
        if (ship.getVariant().hasHullMod("stabilizedshieldemitter")) 
            return "Incompatible with Stabilized Shields";
        
		if (ship.getVariant().hasHullMod("extendedshieldemitter")) 
            return "Incompatible with Extended Shields";
        
        if (ship.getVariant().hasHullMod("hardenedshieldemitter")) 
            return "Incompatible with Hardened Shields";
        
		if (ship.getVariant().hasHullMod("hmp_submattershield")) 
			return "Incompatible with SubmatterShield";
        return null;
		}
		
		
			public boolean isApplicableToShip(ShipAPI ship) {
		return ship != null && (ship.getHullSpec().getDefenseType() == ShieldType.FRONT || ship.getHullSpec().getDefenseType() == ShieldType.OMNI) &&
		((!ship.getVariant().getHullMods().contains("frontemitter"))&&
		(!ship.getVariant().getHullMods().contains("frontshield"))&&
		(!ship.getVariant().getHullMods().contains("advancedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("adaptiveshields"))&&
		(!ship.getVariant().getHullMods().contains("stabilizedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("extendedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hardenedshieldemitter"))&&
		(!ship.getVariant().getHullMods().contains("hmp_submattershield"))&&
		(!ship.getVariant().getHullMods().contains("swp_shieldbypass"))&&
		(!ship.getVariant().getHullMods().contains("hmp_reflectedrage"))&&
		(!ship.getVariant().getHullMods().contains("tahlan_forcedoverdrive")));
	}
}