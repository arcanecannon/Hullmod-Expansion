package data.hullmods;

import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipAPI;

public class MagneticField extends BaseHullMod {
		public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
			stats.getDynamic().getStat(Stats.ELECTRONIC_WARFARE_PENALTY_MULT).modifyMult(id, 0f);
		}
		public String getDescriptionParam(int index, HullSize hullSize) {
			if (index == 0) {
				            return "Deflect";
        }   
			if (index == 1) {
				            return "" + 0 + "%";
        }   
			if (index == 2) {
				            return "Prevents the Installation of ECCM And ECM Package";
        }
		return null;
	}
		    public String getUnapplicableReason(ShipAPI ship) {
				if (ship.getVariant().hasHullMod("eccm"))
					return "Incompatible With ECCMPackage";
				if (ship.getVariant().hasHullMod("ecm"))
					return "Incompatible With ECMPackage";
		return null;
	}
		public boolean isApplicableToShip(ShipAPI ship) {
		 return ship != null && (!ship.getVariant().getHullMods().contains("eccm")&& (!ship.getVariant().getHullMods().contains("ecm"))); 
	}
		
}