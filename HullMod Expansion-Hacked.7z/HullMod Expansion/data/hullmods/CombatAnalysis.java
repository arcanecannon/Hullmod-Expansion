package data.hullmods;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShieldAPI;
import com.fs.starfarer.api.combat.ShieldAPI.ShieldType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;

	public class CombatAnalysis extends BaseHullMod {
			public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
				stats.getFluxCapacity().modifyMult(id, 0.8f);
			}
		
	    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "analyzes enemy patterns and weaknesses";
		}
		if (index == 1) {
            return "" + 1 + "%";
		}
		if (index == 2) {
			return "" + 24 + " seconds";
		}
		if (index == 3) {
			return "" + 25 + "%";
		}
		if (index == 4) {
			return "" + 600 + " seconds";
		}
		if (index == 5) {
			return "" + 20 + "%";
		}
		if (index == 6) {
			return "Incompatible with Weapon Control Supercomputer.";
		}
        return null;
    }
			public String getUnapplicableReason(ShipAPI ship) {
				if(ship.getVariant().hasHullMod("hmp_weaponcontrolcore"))
					return "Incompatible With Weapon Control Supercomputer";
			
				return null;
			}
			public boolean isApplicableToShip(ShipAPI ship) {
				return ship != null && 
				((!ship.getVariant().getHullMods().contains("hmp_weaponcontrolcore")));
			}
			
			public void advanceInCombat(ShipAPI ship, float amount) {
				MutableShipStatsAPI stats = ship.getMutableStats();
				ShipAPI playerShip = Global.getCombatEngine().getPlayerShip();
				float Timer = Global.getCombatEngine().getTotalElapsedTime(false);
				
				
				if (ship.getVariant().hasHullMod("hmp_alphasubsystem")){	
					stats.getHitStrengthBonus().modifyPercent("CombatAnalysis", 35f);
					if( Timer < 960f){
							stats.getBallisticWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (Timer/24f)));
							stats.getEnergyWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (Timer/24f)));}
						else {
							stats.getBallisticWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (960f/24f)));
							stats.getEnergyWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (960f/24f)));
						}
						if (ship == playerShip){
							if( Timer < 960f)
								Global.getCombatEngine().maintainStatusForPlayerShip("Combat Analysis", "graphics/icons/hullsys/active_flare_launcher.png",
								"Combat Analysis: ","" + Math.round(Timer/24f -0.5f) + "% Increased Damage",true);
							else
								Global.getCombatEngine().maintainStatusForPlayerShip("Combat Analysis", "graphics/icons/hullsys/active_flare_launcher.png",
								"Combat Analysis: ","" + Math.round(961f/24f -0.5f) + "% Increased Damage",true);
						}
				}
				else if (ship.getVariant().hasHullMod("hmp_sigmasubsystem")){
						
						if( Timer < 600f)
							stats.getMissileWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (Timer/12f)));
						else 
							stats.getMissileWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (600f/12f)));
						
						if (ship == playerShip){
							if( Timer < 600f)
								Global.getCombatEngine().maintainStatusForPlayerShip("Combat Analysis", "graphics/icons/hullsys/active_flare_launcher.png",
								"Combat Analysis: ","" + Math.round(Timer/12f -0.5f) + "% Increased Missile Damage",true);
							else
								Global.getCombatEngine().maintainStatusForPlayerShip("Combat Analysis", "graphics/icons/hullsys/active_flare_launcher.png",
								"Combat Analysis: ","" + Math.round(601/12f -0.5f) + "% Increased Missile Damage",true);
						}
					}
					else{
						if( Timer < 600f){
							stats.getBallisticWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (Timer/24f)));
							stats.getEnergyWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (Timer/24f)));}
						else {
							stats.getBallisticWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (600f/24f)));
							stats.getEnergyWeaponDamageMult().modifyMult( "CombatAnalysis", 1f + (0.01f * (600f/24f)));
						}
						if (ship == playerShip){
							if( Timer < 600f)
								Global.getCombatEngine().maintainStatusForPlayerShip("Combat Analysis", "graphics/icons/hullsys/active_flare_launcher.png",
								"Combat Analysis: ","" + Math.round(Timer/24f -0.5f) + "% Increased Damage",true);
							else
								Global.getCombatEngine().maintainStatusForPlayerShip("Combat Analysis", "graphics/icons/hullsys/active_flare_launcher.png",
								"Combat Analysis: ","" + Math.round(601/24f -0.5f) + "% Increased Damage",true);
			}
		}
	}
}